13 logos extracted from the supplied composite image.
Each logo is provided in two versions:
1. White-background PNG
2. Transparent-background PNG

Images were enlarged 4x with high-quality Lanczos resampling and mild sharpening.
Because the source image is relatively small, upscaling improves output size and usability but cannot recreate fine detail that was absent from the original.
